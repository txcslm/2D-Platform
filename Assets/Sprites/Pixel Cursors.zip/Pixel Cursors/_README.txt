Made by Astropulse: astropulse.co

To install the cursors, select the "_install Pixel Cursors.inf" file, right click, and select "Install" from the menu.

Press the windows key, go to "Settings", "Personalization", "Themes", "Mouse cursor". In the "Scheme" menu select "Pixel Cursors" from the list. Click "OK".